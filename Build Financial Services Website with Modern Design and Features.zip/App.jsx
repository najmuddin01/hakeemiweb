import React, { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Label } from '@/components/ui/label.jsx';
import { 
  TrendingUp, 
  BarChart3, 
  Calculator, 
  Target, 
  Shield, 
  Settings, 
  Mail, 
  Phone, 
  MapPin,
  MessageCircle,
  ChevronRight,
  Award,
  Users,
  Globe
} from 'lucide-react';
import founderImage from './assets/founder-hakeem.png';
import hakeemiLogo from './assets/hakeemi-logo.jpg';
import bannerHero from './assets/banner-hero.png';
import './App.css';

function App() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Create mailto link with form data
    const subject = encodeURIComponent(`Inquiry from ${formData.name} - ${formData.company}`);
    const body = encodeURIComponent(`
Name: ${formData.name}
Email: ${formData.email}
Company: ${formData.company}

Message:
${formData.message}
    `);
    
    window.location.href = `mailto:najmuddinmustafa007@gmail.com?subject=${subject}&body=${body}`;
  };

  const coreCompetencies = [
    {
      icon: <Calculator className="w-6 h-6" />,
      title: "Budgeting & Forecasting",
      description: "Creating precise financial forecasts to guide strategic decisions."
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: "P&L Management",
      description: "Ensuring profitability and financial stability."
    },
    {
      icon: <BarChart3 className="w-6 h-6" />,
      title: "Financial Analysis",
      description: "Evaluating past performance and forecasting future outcomes."
    },
    {
      icon: <Target className="w-6 h-6" />,
      title: "Costing & Pricing",
      description: "Developing tools for effective cost management and pricing."
    },
    {
      icon: <Settings className="w-6 h-6" />,
      title: "Process Optimization",
      description: "Enhancing efficiency through streamlined processes & automation."
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Risk Assessment",
      description: "Identifying and managing risks with effective mitigation strategies."
    }
  ];

  const services = [
    {
      title: "Financial Planning, Analysis & Reporting",
      description: "We offer comprehensive financial modeling, analysis, and reporting to ensure accurate forecasting, budgeting, and decision-making. Our team delivers customized financial statements, conducts variance analysis, and provides essential insights, helping companies in tracking performance, optimizing resource allocation, and making informed, data-driven strategic choices.",
      image: "📊"
    },
    {
      title: "Costing and Pricing Templates",
      description: "We create structured valuation and pricing templates that assist businesses to compute and regulate expenses, enhance pricing tactics, and streamline decision-making. These templates encompass thorough financial information such as material expenditures, overheads, and profit margins, guaranteeing precise cost control and pricing for multiplied profitability.",
      image: "⚖️"
    },
    {
      title: "Performance Measurement and Improvement",
      description: "We develop customized performance measurement frameworks to track key business metrics, identify areas for improvement, and enhance operational efficiency. By analysing KPIs and business processes, we provide actionable insights that help organizations boost productivity, increase profitability, and achieve sustainable growth.",
      image: "📈"
    },
    {
      title: "Process Optimization",
      description: "We specialize in identifying inefficiencies inside financial procedures and executing solutions to refine workflow, reduce expenditures, and expand accuracy. By utilizing automation and refining systems, we assist businesses to streamline operations, heighten financial performance, and accomplish long-standing operational distinction.",
      image: "⚙️"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-white">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <img 
                src={hakeemiLogo} 
                alt="Hakeemi Financial Consultancy & Transformation" 
                className="h-10 sm:h-12 w-auto"
              />
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#about" className="text-gray-700 hover:text-green-600 transition-colors">About</a>
              <a href="#services" className="text-gray-700 hover:text-green-600 transition-colors">Services</a>
              <a href="#founder" className="text-gray-700 hover:text-green-600 transition-colors">Founder</a>
              <a href="#contact" className="text-gray-700 hover:text-green-600 transition-colors">Contact</a>
            </div>
            <Button 
              onClick={() => window.open('https://wa.me/', '_blank')}
              className="bg-green-600 hover:bg-green-700 text-sm px-3 py-2"
            >
              <MessageCircle className="w-4 h-4 mr-1 sm:mr-2" />
              <span className="hidden sm:inline">WhatsApp</span>
              <span className="sm:hidden">Chat</span>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-16 sm:py-20 overflow-hidden bg-cover bg-center" style={{ backgroundImage: `url(${bannerHero})` }}>
        <div className="absolute inset-0 bg-black/60"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <h1 className="text-3xl sm:text-5xl md:text-7xl font-bold text-white mb-6">
              CORPORATE
              <span className="block text-green-300">COMPANY</span>
              <span className="block">PROFILE</span>
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl text-green-100 max-w-3xl mx-auto leading-relaxed px-4">
              Empowering your financial future through innovative strategies and transformative solutions.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center px-4">
            <Button 
              size="lg" 
              className="bg-green-500 hover:bg-green-400 text-green-900 font-semibold px-6 sm:px-8 py-3 w-full sm:w-auto"
              onClick={() => document.getElementById('contact').scrollIntoView({ behavior: 'smooth' })}
            >
              Get Started
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-green-300 text-white hover:bg-green-300 hover:text-green-900 px-6 sm:px-8 py-3 w-full sm:w-auto"
              onClick={() => document.getElementById('services').scrollIntoView({ behavior: 'smooth' })}
            >
              Our Services
            </Button>
          </div>
        </div>
        {/* Decorative wave */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1200 120" className="w-full h-16 sm:h-20 text-green-50">
            <path d="M0,60 C300,120 900,0 1200,60 L1200,120 L0,120 Z" fill="currentColor"></path>
          </svg>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 sm:py-20 bg-gradient-to-b from-green-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              ABOUT <span className="text-green-600">OUR COMPANY</span>
            </h2>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="space-y-6">
              <p className="text-lg text-gray-700 leading-relaxed">
                With over 20 years empowering large enterprises across India and the Middle East, 
                Hakeemi Financial Consultancy & Transformation provides strategic financial guidance to 
                help businesses reach ambitious goals. Our experts dive deep to understand your 
                operations, then leverage analytical models, bespoke KPI dashboards, and data 
                visualizations to deliver actionable insights.
              </p>
              
              <p className="text-lg text-gray-700 leading-relaxed">
                Our services encompass everything from high-level advisory to detailed budgeting, cost 
                optimization, and process enhancement. We customize financial best practices to boost 
                profitability, streamline operations, mitigate risk, and drive well-informed decision making 
                for sustainable growth.
              </p>
              
              <p className="text-lg text-gray-700 leading-relaxed">
                Armed with state-of-the-art tools, our team operates as an extension of your financial 
                leadership in plain language. We become long-term partners in prosperity through 
                financial mastery, guiding global expansions and daily decisions with equal dexterity. 
                Contact us to elevate your business to new heights.
              </p>
              
              <div className="grid grid-cols-3 gap-6 pt-8">
                <div className="text-center">
                  <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-3 flex items-center justify-center">
                    <Award className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">20+ Years</h3>
                  <p className="text-sm text-gray-600">Experience</p>
                </div>
                <div className="text-center">
                  <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-3 flex items-center justify-center">
                    <Users className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">Large</h3>
                  <p className="text-sm text-gray-600">Enterprises</p>
                </div>
                <div className="text-center">
                  <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-3 flex items-center justify-center">
                    <Globe className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">Global</h3>
                  <p className="text-sm text-gray-600">Reach</p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-gradient-to-br from-green-600 to-green-800 p-8 rounded-2xl shadow-2xl">
                <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
                  <h3 className="text-2xl font-bold text-white mb-4">Our Mission</h3>
                  <p className="text-green-100 leading-relaxed">
                    To empower businesses with innovative financial strategies and transformative 
                    solutions that drive sustainable growth, operational excellence, and long-term success 
                    in an ever-evolving global marketplace.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Competencies */}
      <section className="py-16 sm:py-20 bg-gradient-to-r from-green-600 to-green-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
              CORE <span className="text-green-300">COMPETENCIES</span>
            </h2>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {coreCompetencies.map((competency, index) => (
              <Card key={index} className="bg-white/10 backdrop-blur-sm border-green-300/20 hover:bg-white/20 transition-all duration-300 group">
                <CardHeader>
                  <div className="bg-green-400 p-3 rounded-lg w-fit mb-4 group-hover:scale-110 transition-transform">
                    {competency.icon}
                  </div>
                  <CardTitle className="text-white text-xl">{competency.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-green-100">{competency.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 sm:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              OUR <span className="text-green-600">SERVICES</span>
            </h2>
          </div>
          
          <div className="space-y-12 sm:space-y-16">
            {services.map((service, index) => (
              <div key={index} className={`flex flex-col lg:flex-row items-center gap-8 lg:gap-12 ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
                <div className="lg:w-1/2">
                  <div className="bg-gradient-to-br from-green-100 to-green-50 p-8 rounded-2xl text-center">
                    <div className="text-6xl mb-4">{service.image}</div>
                    <h3 className="text-2xl font-bold text-green-800">{service.title}</h3>
                  </div>
                </div>
                <div className="lg:w-1/2 space-y-4">
                  <h3 className="text-3xl font-bold text-gray-900">{service.title}</h3>
                  <p className="text-lg text-gray-700 leading-relaxed">{service.description}</p>
                  <Button className="bg-green-600 hover:bg-green-700">
                    Learn More
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Founder Section */}
      <section id="founder" className="py-16 sm:py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              OUR <span className="text-green-600">FOUNDER</span>
            </h2>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="space-y-6">
              <h3 className="text-3xl font-bold text-gray-900">Hakeem Fakhruddin</h3>
              <p className="text-xl text-green-600 font-semibold">Founder, Hakeemi Financial Consultancy & Transformation</p>
              
              <p className="text-lg text-gray-700 leading-relaxed">
                Hakeem Fakhruddin, the founder of Hakeemi Financial Consultancy & Transformation, is a 
                distinguished finance expert with over 20 years of experience in the Middle East and India. His 
                career spans high-level management roles at multinational corporations, where he developed 
                expertise in financial planning, analysis, budgeting, costing, project finance, and strategic 
                counselling.
              </p>
              
              <p className="text-lg text-gray-700 leading-relaxed">
                Hakeem has led initiatives that have significantly boosted profitability, optimized operations, and 
                mitigated risks. His accomplishments include numerous leadership awards and the development 
                of fiscal frameworks that have driven substantial revenue growth and cost efficiencies.
              </p>
              
              <div className="flex flex-wrap gap-4 pt-4">
                <div className="bg-green-100 px-4 py-2 rounded-full">
                  <span className="text-green-800 font-medium">Financial Planning</span>
                </div>
                <div className="bg-green-100 px-4 py-2 rounded-full">
                  <span className="text-green-800 font-medium">Strategic Analysis</span>
                </div>
                <div className="bg-green-100 px-4 py-2 rounded-full">
                  <span className="text-green-800 font-medium">Project Finance</span>
                </div>
                <div className="bg-green-100 px-4 py-2 rounded-full">
                  <span className="text-green-800 font-medium">Risk Management</span>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-gradient-to-br from-green-600 to-green-800 p-2 rounded-2xl shadow-2xl">
                <div className="bg-white p-6 rounded-xl text-center">
                  <div className="w-48 h-48 mx-auto mb-6 rounded-full overflow-hidden shadow-lg">
                    <img 
                      src={founderImage} 
                      alt="Hakeem Fakhruddin - Founder" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h4 className="text-2xl font-bold text-gray-900 mb-2">Hakeem Fakhruddin</h4>
                  <p className="text-green-600 font-semibold">Founder</p>
                  <p className="text-sm text-gray-600 mt-2">Hakeemi Financial Consultancy & Transformation</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 sm:py-20 bg-gradient-to-r from-green-600 to-green-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
              CONTACT <span className="text-green-300">US</span>
            </h2>
            <p className="text-lg sm:text-xl text-green-100 max-w-2xl mx-auto px-4">
              Ready to transform your financial future? Get in touch with our experts today.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
            <div className="space-y-8">
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
                <h3 className="text-2xl font-bold text-white mb-6">Get In Touch</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="bg-green-400 p-3 rounded-lg">
                      <Mail className="w-6 h-6 text-green-900" />
                    </div>
                    <div>
                      <p className="text-green-100">Email</p>
                      <p className="text-white font-semibold">najmuddinmustafa007@gmail.com</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="bg-green-400 p-3 rounded-lg">
                      <MessageCircle className="w-6 h-6 text-green-900" />
                    </div>
                    <div>
                      <p className="text-green-100">WhatsApp</p>
                      <Button 
                        variant="link" 
                        className="text-white font-semibold p-0 h-auto"
                        onClick={() => window.open('https://wa.me/', '_blank')}
                      >
                        Chat with us on WhatsApp
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="bg-green-400 p-3 rounded-lg">
                      <MapPin className="w-6 h-6 text-green-900" />
                    </div>
                    <div>
                      <p className="text-green-100">Service Areas</p>
                      <p className="text-white font-semibold">India & Middle East</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm p-8 rounded-xl">
              <h3 className="text-2xl font-bold text-white mb-6">Send us a Message</h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-green-100">Name *</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="bg-white/20 border-green-300/30 text-white placeholder:text-green-200"
                      placeholder="Your full name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-green-100">Email *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="bg-white/20 border-green-300/30 text-white placeholder:text-green-200"
                      placeholder="your.email@company.com"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="company" className="text-green-100">Company</Label>
                  <Input
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleInputChange}
                    className="bg-white/20 border-green-300/30 text-white placeholder:text-green-200"
                    placeholder="Your company name"
                  />
                </div>
                <div>
                  <Label htmlFor="message" className="text-green-100">Message *</Label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={4}
                    className="bg-white/20 border-green-300/30 text-white placeholder:text-green-200"
                    placeholder="Tell us about your financial consulting needs..."
                  />
                </div>
                <Button 
                  type="submit" 
                  size="lg" 
                  className="w-full bg-green-400 hover:bg-green-300 text-green-900 font-semibold"
                >
                  Send Message
                  <Mail className="w-5 h-5 ml-2" />
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <img 
                  src={hakeemiLogo} 
                  alt="Hakeemi Financial Consultancy & Transformation" 
                  className="h-12 w-auto"
                />
              </div>
              <p className="text-gray-400">
                Empowering your financial future through innovative strategies and transformative solutions.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Financial Planning & Analysis</li>
                <li>Costing & Pricing Templates</li>
                <li>Performance Measurement</li>
                <li>Process Optimization</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact</h4>
              <div className="space-y-2 text-gray-400">
                <p>najmuddinmustafa007@gmail.com</p>
                <p>India & Middle East</p>
                <Button 
                  variant="link" 
                  className="text-green-400 p-0 h-auto"
                  onClick={() => window.open('https://wa.me/', '_blank')}
                >
                  WhatsApp Chat
                </Button>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Hakeemi Financial Consultancy & Transformation. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
