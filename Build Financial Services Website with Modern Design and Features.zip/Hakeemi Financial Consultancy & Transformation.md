# Hakeemi Financial Consultancy & Transformation

A modern, professional website for Hakeemi Financial Consultancy & Transformation, built with React and Tailwind CSS.

## About

Hakeemi Financial Consultancy & Transformation provides strategic financial guidance to help businesses reach ambitious goals. With over 20 years of experience empowering large enterprises across India and the Middle East, we offer comprehensive financial solutions including:

- Financial Planning, Analysis & Reporting
- Costing and Pricing Templates
- Performance Measurement and Improvement
- Process Optimization

## Features

- **Modern Design**: Clean, professional layout with green color scheme matching brand identity
- **Fully Responsive**: Optimized for desktop and mobile devices, ensuring a seamless user experience.
- **Contact Form**: Integrated contact form that sends emails directly to the business
- **WhatsApp Integration**: Direct WhatsApp contact buttons for instant communication
- **Smooth Animations**: Modern UI with hover effects and smooth transitions
- **Founder's Picture**: Integrated high-resolution image of Hakeem Fakhruddin in the founder section.
- **SEO Optimized**: Proper meta tags and semantic HTML structure

## Technology Stack

- **React 18**: Modern React with hooks and functional components
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Vite**: Fast build tool and development server
- **Lucide React**: Beautiful, customizable icons
- **shadcn/ui**: High-quality UI components

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or pnpm

### Installation

1. Clone the repository:
```bash
git clone https://github.com/user/hakeemi-website.git
cd hakeemi-website
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open [http://localhost:5173](http://localhost:5173) in your browser.

### Building for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## Contact Information

- **Email**: najmuddinmustafa007@gmail.com
- **WhatsApp**: Available through website buttons
- **Service Areas**: India & Middle East

## License

© 2024 Hakeemi Financial Consultancy & Transformation. All rights reserved.
